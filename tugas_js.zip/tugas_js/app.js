const students = [
    {
        name: "karim",
        className: "XI RPL",
        scores: [80, 80, 85],
        attendance: 80,
        hasViolation: false
    },
        {
        name: "imam",
        className: "XI RPL",
        scores: [97, 95, 100],
        attendance: 99,
        hasViolation: false
    },    {
        name: "acin",
        className: "XI RPL",
        scores: [75, 90, 80],
        attendance: 70,
        hasViolation: true
    },    {
        name: "aloy",
        className: "XI RPL",
        scores: [60, 60, 85],
        attendance: 60,
        hasViolation: true
    },    {
        name: "sahlui",
        className: "XI RPL",
        scores: [80, 70, 85],
        attendance: 80,
        hasViolation: false
    },    {
        name: "bahenol",
        className: "XI RPL",
        scores: [81, 80, 85],
        attendance: 82,
        hasViolation: false
    },    {
        name: "benihoy",
        className: "XI RPL",
        scores: [88, 70, 75],
        attendance: 85,
        hasViolation: true
    },    {
        name: "agungs",
        className: "XI RPL",
        scores: [80, 90, 85],
        attendance: 80,
        hasViolation: false
    },    {
        name: "amriee",
        className: "XI RPL",
        scores: [76, 90, 85],
        attendance: 87,
        hasViolation: true
    },
    // tambahkan siswa lainnya
]; 

// MENAMPILKAN TANGGAL HARI INI
const tanggalBaru = new Date();
console.log({tanggalBaru});
console.log(tanggalBaru.toString());
console.log(tanggalBaru.toLocaleString());
console.log("HSI STUDENT REPORT CARD");

// lOOP UNTUK SETIAP SISWA
for (let i = 0; i < students.length; i++) {
    const student = students[i]

    // 1. Hitung Total dan rata-rata nilai
    let totalScore = 0;
    for (let j = 0; j < student.scores.length; j++ ) {
        totalScore += student.scores[j];
    }
    const averageScore = totalScore / student.scores.length;

//  2. Tentukan grade berdasarkan nilai
let grade = "E";
if (averageScore >= 95){
    grade = "AA+";
} else if (averageScore >= 85){
    grade = "A";
}else if (averageScore >= 75){
    grade = "B";
}else if (averageScore >= 60){
    grade = "C"
} else if (averageScore >= 55){
    grade = "D";
}


// 3. Tentukan Status Kelulusan/Keterangan
let status = "LULUS";
    if (averageScore < 70 || student.attendance < 90 || student.hasViolation) {
        status = "PERLU EVALUASI(NGULANG)";
}

// 4. Cetak Report Card
console.log(`Student #${i + 1}`);
console.log(`Nama        : ${student.name}`);
console.log(`Kelas       : ${student.className}`);
console.log(`Nilai       : [${student.scores.join(", ")}]`);
console.log(`Total       : ${totalScore}`);
console.log(`Rata-rata   : ${averageScore.toFixed(2)}`);
console.log(`Grade       : ${grade}`);
console.log(`Kehadiran   : ${student.attendance}%`);
console.log(`Pelanggaran : ${student.hasViolation ? "Ada" : "Tidak Ada"}`);
console.log(`Status      : ${status}`);
console.log("-----------------------------------\n");
}